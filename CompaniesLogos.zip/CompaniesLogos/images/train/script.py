import os

# Set your root folder path
root_folder = 'C:/Users/HP/Downloads/CompaniesLogos/images/val'

# Supported image extensions (you can add more if needed)
image_extensions = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff')

# Traverse the directory
for subdir, _, files in os.walk(root_folder):
    # Filter image files in the subdir
    image_files = [file for file in files if file.lower().endswith(image_extensions)]
    
    # If more than one image is found, delete all but the first one
    if len(image_files) > 1:
        # Keep the first image
        images_to_delete = image_files[1:]  # Retain the first one, delete the rest

        # Delete the extra images
        for image in images_to_delete:
            image_path = os.path.join(subdir, image)
            os.remove(image_path)
            print(f"Deleted: {image_path}")
